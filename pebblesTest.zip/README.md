# PebbleGame
### Usage
pebbles.jar can be run with following code:
  java -jar pebbles.jar

Players: - Any positive number can be simulated but with very large numbers ensure the .txt or .csv files have enough pebble weights to support this.

java -cp .;junit-4.12 org.junit.runner.JUnitCore pebblegame.FullTestSuite
