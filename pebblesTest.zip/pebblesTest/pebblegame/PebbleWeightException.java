package pebblegame;

public class PebbleWeightException extends Exception {
    public PebbleWeightException (String message){
        super(message);
    }
}