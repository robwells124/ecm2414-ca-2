package pebblegame;

public class UserQuitException extends Exception{
    public UserQuitException(String message){
        super(message);
    }
}

